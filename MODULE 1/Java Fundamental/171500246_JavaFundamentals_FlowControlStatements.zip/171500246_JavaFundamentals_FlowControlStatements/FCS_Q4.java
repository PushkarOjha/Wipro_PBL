public class FCS_Q4 {
	public static void main(String[] args) {
		char first = 's';
		char second = 'e';

		if(first < second){
			System.out.println(first+ ","+ second);
		}

		else{
			System.out.println(second+ ","+ first);
		}
	}
}