public class LB_Q3{
	public static void main(String [] args) {
		int number1 = Integer.parseInt(args[0]);
		int number2 = Integer.parseInt(args[1]);
		System.out.println("The sum of " +args[0]+ " and " +args[1]+ " is " +(number2 + number1));
	}
}
� 2020 GitHub, Inc.