public class Luggage extends Compartment{
	public String notice()
	{
		return "This is luggage compartment";
	}
}
