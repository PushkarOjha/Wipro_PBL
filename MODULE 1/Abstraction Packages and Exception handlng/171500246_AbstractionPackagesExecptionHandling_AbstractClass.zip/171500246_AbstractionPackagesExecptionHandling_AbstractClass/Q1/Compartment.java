abstract public class Compartment {
	public abstract String notice();
}