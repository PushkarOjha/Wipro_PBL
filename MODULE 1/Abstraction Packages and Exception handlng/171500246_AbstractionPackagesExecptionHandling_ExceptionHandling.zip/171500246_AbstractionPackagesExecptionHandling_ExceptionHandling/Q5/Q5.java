public class Q5 {

	public static void main(String[] args) {
		String name = args[0];
		int age = Integer.parseInt(args[1]);
		
		try {
			if(age <18 || age > 60) {
				throw new MyException() ;
			}
		} catch (MyException e) {
			e.printStackTrace();
		}
	}
	
}