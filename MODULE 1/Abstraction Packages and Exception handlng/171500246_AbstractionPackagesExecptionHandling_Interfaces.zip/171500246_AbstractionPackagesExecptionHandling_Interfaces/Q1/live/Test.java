package 171500246_AbstractionPackagesExecptionHandling_Interfaces.Q1.live;

import 171500246_AbstractionPackagesExecptionHandling_Interfaces.Q1.music.*;
import 171500246_AbstractionPackagesExecptionHandling_Interfaces.Q1.music.string.Veena;
import 171500246_AbstractionPackagesExecptionHandling_Interfaces.Q1.music.wind.Saxophone;

public class Test {

	public static void main(String[] args) {
		Veena v = new Veena();
		v.play();
		Saxophone s= new Saxophone();
		s.play();
		Playable p = s;
		s.play();
		p = v;
		v.play();
	}

}