package 171500246_AbstractionPackagesExecptionHandling_Interfaces.Q1.music.string;

import 171500246_AbstractionPackagesExecptionHandling_Interfaces.Q1.music.Playable;

public class Veena implements Playable{
	public void play()
	{
		System.out.println("Veena Playing");
	}
}