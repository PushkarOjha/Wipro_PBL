package 171500246_AbstractionPackagesExecptionHandling_Interfaces.Q1.music.wind;

import 171500246_AbstractionPackagesExecptionHandling_Interfaces.Q1.music.Playable;

public class Saxophone implements Playable{
	public void play()
	{
		System.out.println("Saxophone playing");
	}
}