public class TestEmployee {
	public static void main(String[]  args) {
		Employee obj = new Employee("Abc", 200000.0, 2019, "DD-15145020");
		obj.display();
	}
}