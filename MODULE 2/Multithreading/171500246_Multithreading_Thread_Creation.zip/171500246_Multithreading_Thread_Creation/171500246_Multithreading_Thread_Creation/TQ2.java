import java.util.Random;

public class TQ2 implements Runnable
{
    public static void main(String[] args) {
        TQ2 a = new TQ2();
        Thread t1 = new Thread();
        t1.start();
    }

    @Override
    public void run() {
        Random random = new Random();
        String colours[] = {"white", "blue", "black", "green", "red", "yellow"};
        int index= random.nextInt();
        while (index!= 4) {
            System.out.println(colours[index]);
        }
    }
}