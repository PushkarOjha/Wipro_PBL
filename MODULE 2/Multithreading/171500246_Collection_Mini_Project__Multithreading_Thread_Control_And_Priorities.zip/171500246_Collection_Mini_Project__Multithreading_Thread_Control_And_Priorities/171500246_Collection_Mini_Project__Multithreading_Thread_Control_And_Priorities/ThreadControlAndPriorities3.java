public class ThreadControlAndPriorities3 implements Runnable
{
    @Override
    public void run() {
        for (int i = 1; i <= 10; i++) {
            System.out.println(Thread.currentThread().getName() + " " + i);
        }
    }

    public static void main(String[] args) {
        ThreadControlAndPriorities3 object = new ThreadControlAndPriorities3();
        Thread thread1 = new Thread(object,"first thread");
        Thread thread2 = new Thread(object,"second thread");
        Thread thread3 = new Thread(object,"third thread");

        thread1.setPriority(Thread.MAX_PRIORITY);
        thread2.setPriority(Thread.MIN_PRIORITY);
        thread3.setPriority(Thread.NORM_PRIORITY);

        thread1.start();
        thread2.start();
        thread3.start();
    }
}
