public class ThreadControlAndPriorities2
{
    public void printEven()
    {
        System.out.println("Even number are:- ");
        for (int i = 2; i < 20; i++) {
            if(i%2 == 0)
                System.out.println(i);
        }
    }

    public void printOdd()
    {
        System.out.println("Odd numbers are:- ");
        for (int i = 2; i < 20; i++) {
            if (i%2 != 0)
                System.out.println(i);
        }
    }

    public static void main(String[] args){
        ThreadControlAndPriorities2 object = new ThreadControlAndPriorities2();

        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                object.printEven();
            }
        });

        Thread thread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                object.printOdd();
            }
        });

        thread1.start();
        thread2.start();

        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
