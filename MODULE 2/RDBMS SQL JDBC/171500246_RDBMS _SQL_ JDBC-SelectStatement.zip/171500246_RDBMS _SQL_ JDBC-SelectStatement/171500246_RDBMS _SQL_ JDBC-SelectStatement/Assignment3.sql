select distinct job_id
from employees;