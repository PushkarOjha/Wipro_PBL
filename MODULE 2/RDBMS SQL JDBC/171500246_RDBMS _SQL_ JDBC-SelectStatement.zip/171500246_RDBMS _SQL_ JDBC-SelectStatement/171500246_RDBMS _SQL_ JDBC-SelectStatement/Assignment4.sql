select employee_id EmP#, last_name Employee, job_id Job, hire_date "Hire Date"
from employees;