desc departments;
select * from departments;