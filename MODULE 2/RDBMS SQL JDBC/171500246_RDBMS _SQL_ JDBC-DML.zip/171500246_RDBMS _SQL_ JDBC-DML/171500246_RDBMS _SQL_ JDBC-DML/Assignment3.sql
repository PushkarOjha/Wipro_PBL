INSERT INTO my_employee VALUES (201,'Michael','Harstein',20,13000);
