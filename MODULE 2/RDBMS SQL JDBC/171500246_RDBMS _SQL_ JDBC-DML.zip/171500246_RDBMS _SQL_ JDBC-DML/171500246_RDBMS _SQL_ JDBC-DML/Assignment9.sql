DELETE FROM my_employee
WHERE first_name LIKE '%man%'
OR last_name LIKE '%man%';
