UPDATE my_employee SET
last_name='Higgins'
WHERE employee_id=202;