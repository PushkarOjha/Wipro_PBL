UPDATE my_employee SET
salary=salary*1.10
WHERE department_id=90;