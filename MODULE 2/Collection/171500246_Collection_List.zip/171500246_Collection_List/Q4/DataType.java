public class DataType {
	
	int a;
	float b;
	double c;
	
	public void addInteger(int num) {
		a = num;
	}
	
	public void addFloat(float num) {
		b = num;
	}
	
	public  void addDouble(double num) {
		c = num;
	}
}